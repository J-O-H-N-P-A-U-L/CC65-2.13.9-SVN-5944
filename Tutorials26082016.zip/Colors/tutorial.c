#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <stdlib.h>
#include <peekpoke.h>

#include "colors.h"

extern char lynxtgi[];

void wait_joystick()
{
	__asm__("press:		lda $FCB0");
	__asm__("					beq press");
	__asm__("release: lda $FCB0");
	__asm__("					bne release");
}

void show_palette(const char* header)
{
	char index = 0;
	char text[5];

	tgi_clear();
	
	tgi_setbgcolor(TUTORIAL_COLOR_BLACK);
	tgi_setcolor(TUTORIAL_COLOR_WHITE);
	tgi_outtextxy(10, 0, header);

	tgi_gotoxy(10, 10);
	for (index = 0; index < 16; index++)
	{
		itoa(index, text, 16);
		tgi_setcolor(index);
		tgi_outtext(text);
	}

	tgi_setbgcolor(TUTORIAL_COLOR_WHITE);
	tgi_gotoxy(10, 20);
	for (index = 0; index < 16; index++)
	{
		itoa(index, text, 16);
		tgi_setcolor(index);
		tgi_outtext(text);
	}

	tgi_updatedisplay();
	while (tgi_busy());
}

void initialize()
{
	tgi_install(&lynxtgi);
	tgi_init();
	CLI();
	
	while (tgi_busy());

	tgi_setbgcolor(TUTORIAL_COLOR_BLACK); 
	
	tgi_setcolor(TUTORIAL_COLOR_BLACK);
	tgi_clear();
}

void setpalette(const int* palette)
{
	char index;
	for (index = 0; index < 0x10; index++)
	{
		POKE(0xFDA0 + index, palette[index] >> 8);
		POKE(0xFDB0 + index, palette[index] & 0xFF);
	}
}

void main(void) 
{	
	initialize();

	while (1)
	{
		tgi_setpalette(tgi_getdefpalette());
		show_palette("Default palette");
		wait_joystick();

		setpalette(rawpalette);
		//tgi_setpalette(palette);
		show_palette("Custom palette");
		wait_joystick();
	};
}