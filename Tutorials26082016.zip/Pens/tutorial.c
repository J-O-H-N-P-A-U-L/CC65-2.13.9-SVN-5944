#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <joystick.h>
#include <sprites.h>
#include <stdlib.h>
#include <peekpoke.h>

extern char lynxtgi[];
extern char lynxjoy[];
extern char robot[];
extern char robotcentered[];

char singlepixel_data[4] = { 0x03, 0x87, 0x80, 0x00 }; // 1 0000 111 1 0000 000 

char joy;

void wait_joystick()
{
	__asm__("press:		lda $FCB0");
	__asm__("					beq press");
	__asm__("release: lda $FCB0");
	__asm__("					bne release");
}

sprite_collideable robotsprite = 
{
	0x0, 
	{
		BPP_4 | TYPE_NORMAL,
		REHV,
		NO_COLLIDE | 0x05,
		0,
		robot,
		0, 50,
		0x0200, 0x0200,
		{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
	}
};

void show_screen()
{
	char text[20];
	char index;
	unsigned char line = 5;
	
	tgi_clear();

	for (index = 0; index < 0x10; index++)
	{
		tgi_setcolor(index);
		tgi_bar(index * 10, 0, index*10+16, 102);
	}

	wait_joystick();

	tgi_clear();

	tgi_setcolor(COLOR_RED);
	tgi_bar(0, 0, 160, 102);

	for (index = 0; index < 8; index++)
	{
		robotsprite.scb.posx = 20 * index + 2;
		robotsprite.scb.posy = 5;

		robotsprite.scb.b0 = BPP_4 | index;
		tgi_sprite(&robotsprite.scb);
	}

	while (line < (5 + 16))
	{
		for (index = 0; index < 80; index++)
		{
			POKE(0xE018 + index + (50 + line) * 80, PEEK(0xA058 + index + line * 80));
		}
		line++;
	}

	tgi_updatedisplay();
	while (tgi_busy());
}

void initialize()
{
	tgi_install(&lynxtgi);
	joy_install(&lynxjoy);
	tgi_init();
	tgi_setcollisiondetection(1);
	CLI();
	
	while (tgi_busy());

	tgi_setbgcolor(COLOR_BLACK); 	
	tgi_setcolor(COLOR_BLACK);
	tgi_clear();
}

void read_input()
{
	joy = joy_read(JOY_1);

	if (JOY_BTN_LEFT(joy))
	{
		if (robotsprite.scb.posx > 0) robotsprite.scb.posx--;
	}
	if (JOY_BTN_RIGHT(joy))
	{
		if (robotsprite.scb.posx < 160) robotsprite.scb.posx++;
	}
	if (JOY_BTN_DOWN(joy))
	{
		if (robotsprite.scb.posy < 100) robotsprite.scb.posy++;
	}
	if (JOY_BTN_UP(joy))
	{
		if (robotsprite.scb.posy > 0) robotsprite.scb.posy--;
	}
}

void main(void) 
{	
	initialize();

	while (1)
	{
		read_input();
		show_screen();
	};
}