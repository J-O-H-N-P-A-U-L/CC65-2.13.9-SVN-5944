#include <stdlib.h>
#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <peekpoke.h>

extern char lynxtgi[];

void show_screen()
{
	char text[20];  
	tgi_outtextxy(10, 0, "Resolution:");
	itoa(tgi_getxres(), text, 10);
	tgi_outtextxy(10, 10, text); 
	itoa(tgi_getyres(), text, 10);
	tgi_outtextxy(40, 10, text);
	
	tgi_outtextxy(10, 20, "Max coor (x,y):");	
	tgi_gotoxy(10, 30);
	tgi_outtext("(0x");
	itoa(tgi_getmaxx(), text, 16);
	tgi_outtext(text);
	tgi_outtext(",0x");
	itoa(tgi_getmaxy(), text, 16);
	tgi_outtext(text);
	tgi_outtext(")");
 
	tgi_updatedisplay();
}

void show_screen2()
{
	const char* msg;
	char i;
 
	tgi_clear();
	tgi_setcolor(COLOR_WHITE);
	
	for (i = 0; i < 11; i++)
	{
		msg = tgi_geterrormsg(i);
		tgi_setbgcolor(i + 1);
		tgi_outtextxy(0, i * 9, msg);
	} 
 
	tgi_updatedisplay();
	while(1) {};
}

void initialize()
{
	tgi_install(&lynxtgi);
	tgi_init();
	CLI();
	
	while (tgi_busy()) 
	{ 
	};

	tgi_setpalette(tgi_getdefpalette());	
	tgi_setcolor(COLOR_WHITE);
	tgi_setbgcolor(COLOR_BLACK); 
	tgi_clear();
}

void main(void) 
{	
	initialize();

	while (1)
	{
		if (!tgi_busy())
		{
			show_screen2();
		}
	};
}