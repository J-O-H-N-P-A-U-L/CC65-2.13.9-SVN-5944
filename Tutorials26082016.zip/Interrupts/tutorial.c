#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <stdlib.h>

extern char lynxtgi[];
extern char framecount;
extern char lasthblcount;

void show_screen()
{ 
	char text[2];
	tgi_clear();
	
	tgi_setcolor(COLOR_WHITE);
	itoa(lasthblcount, text, 10);
	tgi_outtextxy(0, 32, "Number of HBL IRQs:");
	tgi_outtextxy(10, 48, text);

	tgi_updatedisplay();
}

void initialize()
{
	tgi_install(&lynxtgi);
	tgi_init();
	CLI();
	
	while (tgi_busy());

	tgi_setbgcolor(COLOR_BLACK); 
	tgi_setpalette(tgi_getdefpalette());
	
	tgi_setcolor(COLOR_BLACK);
	tgi_clear();

	// Start HBL interrupt
	__asm__("lda #$80");
	__asm__("tsb $fd01");
}

void main(void) 
{	
	initialize();

	while (1)
	{
		if (!tgi_busy())
		{
			show_screen();
		}
	};
}