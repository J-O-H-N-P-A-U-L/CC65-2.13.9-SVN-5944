#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <joystick.h>
#include <stdlib.h>

#define true 1
#define false 0

extern unsigned char lynxtgi[];
extern unsigned char lynxjoy[];

void wait_joystick()
{
	__asm__("press:		lda $FCB0");
	__asm__("					beq press");
	__asm__("release: lda $FCB0");
	__asm__("					bne release");
}

void initialize()
{
	tgi_install(&lynxtgi);
	joy_install(&lynxjoy);

	tgi_init();
	CLI();

	while (tgi_busy());

	tgi_setbgcolor(COLOR_BLACK);
	tgi_clear();
}

void main(void) 
{	
	unsigned char joy, value, control;
	char reload = true, flag = false;
	char text[20], text2[20];

	initialize();
	itoa(0, text2, 16);

	MIKEY.timer1.control = 0x1E;
	MIKEY.timer1.reload = 255;
	MIKEY.timer1.count = 255;

	MIKEY.timer3.control = 0x1F;
	MIKEY.timer3.reload = 255;
	MIKEY.timer3.count = 255;

	MIKEY.timer5.control = 0x1F;
	MIKEY.timer5.reload = 4;
	MIKEY.timer5.count = 0;

	MIKEY.timer7.control = 0x1F;
	MIKEY.timer7.reload = 2;
	MIKEY.timer7.count = 2;

	while (1)
	{
		value = joy_read(JOY_1);
		if (value != 0 && joy == 0)
		{
			joy = value;
		}

		if (joy != 0 && value == 0) 
		{
			if (JOY_BTN_FIRE(joy))
			{
				MIKEY.timer5.control |= 0x40;
			}
			if (JOY_BTN_FIRE2(joy))
			{
				reload = !reload;
				if (reload)
					control = 0x1F;
				else
					control = 0x5F;
				MIKEY.timer5.control = control;
			}
			joy = 0;
		}

		while (!tgi_busy())
		{
			tgi_clear();
			tgi_outtextxy(10, 0, "Linked timers");

			itoa(MIKEY.timer1.count, text, 10);
			tgi_outtextxy(10, 20, "Count T1:");
			tgi_outtextxy(115, 20, text);

			itoa(MIKEY.timer3.count, text, 10);
			tgi_outtextxy(10, 30, "Count T3:");
			tgi_outtextxy(115, 30, text);

			itoa(MIKEY.timer5.count, text, 10);
			tgi_outtextxy(10, 40, "Count T5:");
			tgi_outtextxy(115, 40, text);

			itoa(MIKEY.timer7.count, text, 10);
			tgi_outtextxy(10, 50, "Count T7:");
			tgi_outtextxy(115, 50, text);

			tgi_outtextxy(10, 60, "Reload T5:");
			tgi_outtextxy(115, 60, reload ? "Yes" : "No");

			tgi_outtextxy(10, 70, "Timer5 done:");
			tgi_outtextxy(115, 70, (MIKEY.timer5.control2 & 0x08) > 0 ? "Yes" : "No");

			itoa(MIKEY.timer1.control2, text, 16);
			tgi_outtextxy(10, 80, text);
			itoa(MIKEY.timer3.control2, text, 16);
			tgi_outtextxy(40, 80, text);
			itoa(MIKEY.timer5.control2, text, 16);
			tgi_outtextxy(70, 80, text);
			
			//value = MIKEY.timer5.control2;
			//if ((value & 0x08) != 0x08)
			//	itoa(value, text2, 16);
			//tgi_outtextxy(70, 80, text2);
			
			itoa(MIKEY.timer7.control2, text, 16);
			tgi_outtextxy(100, 80, text);

			tgi_updatedisplay();
		}
	}
}

void main3(void) 
{	
	unsigned char joy, value, control;
	char reload = true, flag = false;
	char text[20], text2[20];

	initialize();
	itoa(0, text2, 16);

	MIKEY.timer1.control = 0x1E;
	MIKEY.timer1.reload = 255;
	MIKEY.timer1.count = 255;

	MIKEY.timer3.control = 0x1F;
	MIKEY.timer3.reload = 255;
	MIKEY.timer3.count = 255;

	MIKEY.timer5.control = 0x1F;
	MIKEY.timer5.reload = 4;
	MIKEY.timer5.count = 4;

	MIKEY.timer7.control = 0x1F;
	MIKEY.timer7.reload = 2;
	MIKEY.timer7.count = 2;

	while (1)
	{
		value = joy_read(JOY_1);
		if (value != 0 && joy == 0)
		{
			joy = value;
		}

		if (joy != 0 && value == 0) 
		{
			if (JOY_BTN_FIRE(joy))
			{
				MIKEY.timer5.control |= 0x40;
			}
			if (JOY_BTN_FIRE2(joy))
			{
				reload = !reload;
				if (reload)
					control = 0x1F;
				else
					control = 0x5F;
				MIKEY.timer5.control = control;
			}
			joy = 0;
		}

		while (!tgi_busy())
		{
			tgi_clear();
			tgi_outtextxy(10, 0, "Linked timers");

			itoa(MIKEY.timer1.count, text, 10);
			tgi_outtextxy(10, 20, "Count T1:");
			tgi_outtextxy(115, 20, text);

			itoa(MIKEY.timer3.count, text, 10);
			tgi_outtextxy(10, 30, "Count T3:");
			tgi_outtextxy(115, 30, text);

			itoa(MIKEY.timer5.count, text, 10);
			tgi_outtextxy(10, 40, "Count T5:");
			tgi_outtextxy(115, 40, text);

			itoa(MIKEY.timer7.count, text, 10);
			tgi_outtextxy(10, 50, "Count T7:");
			tgi_outtextxy(115, 50, text);

			tgi_outtextxy(10, 60, "Reload T5:");
			tgi_outtextxy(115, 60, reload ? "Yes" : "No");

			tgi_outtextxy(10, 70, "Timer5 done:");
			tgi_outtextxy(115, 70, (MIKEY.timer5.control2 & 0x08) > 0 ? "Yes" : "No");

			itoa(MIKEY.timer1.control2, text, 16);
			tgi_outtextxy(10, 80, text);
			itoa(MIKEY.timer3.control2, text, 16);
			tgi_outtextxy(40, 80, text);
			itoa(MIKEY.timer5.control2, text, 16);
			tgi_outtextxy(70, 80, text);
			
			//value = MIKEY.timer5.control2;
			//if ((value & 0x08) != 0x08)
			//	itoa(value, text2, 16);
			//tgi_outtextxy(70, 80, text2);
			
			itoa(MIKEY.timer7.control2, text, 16);
			tgi_outtextxy(100, 80, text);

			tgi_updatedisplay();
		}
	}
}

void main2(void)
{	
	unsigned char joy, value, control;
	char reload = true, reset = false;
	char text[20];

	initialize();

	MIKEY.timer1.control = 0x1E; // %00011000
	MIKEY.timer1.reload = 100;
	MIKEY.timer1.count = 100;
	
	while (1)
	{
		value = joy_read(JOY_1);
		if (value != 0 && joy == 0)
		{
			joy = value;
		}

		if (joy != 0 && value == 0) 
		{
			if (JOY_BTN_UP(joy))
			{
				MIKEY.timer1.count = 100;
			}
			if (JOY_BTN_FIRE2(joy))
			{
				reset = !reset;
			}
			if (JOY_BTN_FIRE(joy))
			{
				reload = !reload;
				if (reload) 
					control = 0x1E;
				else
					control = 0x0E;
				
				// Add "Reset Timer Done" bit
				if (reset) control += 0x40;
			}
			joy = 0;
		}

		MIKEY.timer1.control = control;

		while (!tgi_busy())
		{
			tgi_clear();
			tgi_outtextxy(10, 0, "Simple timer");

			itoa(MIKEY.timer1.count, text, 10);
			tgi_outtextxy(10, 20, "Count1:");
			tgi_outtextxy(110, 20, text);
			
			tgi_outtextxy(10, 30, "Reload:");
			tgi_outtextxy(110, 30, reload ? "Yes" : "No");
			tgi_outtextxy(10, 40, "Control2:");
			itoa((MIKEY.timer1.control2 & 0x0F), text, 10);
			//tgi_outtextxy(110, 40, ((MIKEY.timer1.control2 & 0x08) == 0x08) ? "Yes" : "No");
			tgi_outtextxy(110, 40, text);
			tgi_outtextxy(10, 50, "Reset timer");
			tgi_outtextxy(10, 60, "done flag:");
			tgi_outtextxy(110, 60, reset ? "Yes" : "No");

			tgi_updatedisplay();
		}
	}

}