#include <6502.h>
#include <lynx.h>
#include <tgi.h>

#include <colors.h>
#include <sprites.h>

extern char lynxtgi[];
extern char robot[];
extern char robotcentered[];
extern char leave0[];
extern char leave1[];
extern char leave2[];
extern char leave3[];

char singlepixel_data[4] = { 0x03, 0x87, 0x80, 0x00 }; // 1 0000 111 1 0000 000 

char allcolors_data[17] = 
{ 
	0x04, 0x98, 0x09, 0x18,  // 1 0011 0000 0001 0010 0011 000 
	0x04, 0x9a, 0x2b, 0x38,  // 1 0011 0100 0101 0110 0111 000 
	0x04, 0x9c, 0x4d, 0x58,  // 1 0011 1000 1001 1010 1011 000 
	0x04, 0x9e, 0x6f, 0x78,  // 1 0011 1100 1101 1110 1111 000 
	0x00
};

void wait_joystick()
{
	__asm__("press:		lda $FCB0");
	__asm__("					beq press");
	__asm__("release: lda $FCB0");
	__asm__("					bne release");
}

sprite_simple singlepixel = 
{
	BPP_4 | TYPE_NORMAL,
	REUSEPAL,
	0x01,
	0,
	&singlepixel_data,
	5, 20
};

sprite_sizable allcolors = 
{
	BPP_4 | TYPE_NORMAL, 
	REHV, 
	0x01,
	0,
	&allcolors_data,
	10, 20, 
	0x0100, 0x0100,
	{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
};

sprite_sizable leaves = 
{
	BPP_4 | TYPE_NORMAL, 
	REHV, 
	0x01,
	0,
	&leave0,
	80, 20,
	0x0400, 0x0100,
	{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
};

sprite_complete tilted = 
{
	BPP_4 | TYPE_NORMAL, 
	REHVST, // Notice typo in word stretch
	0x01,
	0,
	&allcolors_data,
	50, 20, 
	0x0500, 0x0500,
	0x0000, 0x0100,
	{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
};

sprite_complete stretched = 
{
	BPP_4 | TYPE_NORMAL, 
	REHVST, 
	0x01,
	0,
	&allcolors_data,
	20, 50, 
	0x0100, 0x0100,
	0x0100, 0x0000,
	{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
};

sprite_complete robotsprite = 
{
	BPP_4 | TYPE_NORMAL, 
	REHVST, 
	0x01,
	0,
	&robot,
	20, 50, 
	0x0100, 0x0100,
	0x0000, 0x0000,
	{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
};

sprite_complete robot2 = 
{
	BPP_4 | TYPE_NORMAL, 
	REHVST, 
	0x01,
	0,
	&robotcentered,
	80, 50, 
	0x0100, 0x0100,
	0x007f, 0x0000,
	{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
};

sprite_complete robots[150];

void prepare_robots()
{
	char index, color;
	void *next;
	sprite_complete* sprite;
	
	next = 0x0000;
	for (index = 0; index < 150; index++)
	{
		sprite = &robots[index];
		*sprite = robotsprite; // Copy structure
		sprite->next = next;
		sprite->posx = (index * 10) % 150;
		sprite->posy = (index / 15 + 1) * 10;
		color = index % 16;
		sprite->palette[1] = (color << 4) + color + 1;
		next = sprite;
	}
}

void show_screen()
{
//	sprite_complete* sprite;

	tgi_clear();

	tgi_setcolor(TUTORIAL_COLOR_WHITE);
	tgi_outtextxy(0, 0, "Stretch and tilt"); 

	tgi_sprite(&singlepixel);
	tgi_sprite(&allcolors);

	allcolors.posx = 20;
	allcolors.sizex = 0x500;
	allcolors.sizey = 0x500;
	tgi_sprite(&allcolors);
	
	tgi_sprite(&stretched);
	tgi_sprite(&tilted);
	
	tgi_updatedisplay();
	while (tgi_busy());
	wait_joystick();

	tgi_clear();

	tgi_setcolor(TUTORIAL_COLOR_WHITE);
	tgi_outtextxy(0, 0, "Chained sprites"); 

	prepare_robots();
	tgi_sprite(&robots[149]);

	tgi_updatedisplay();
	while (tgi_busy());
	wait_joystick();

	tgi_clear();
	tgi_setcolor(TUTORIAL_COLOR_WHITE);
	tgi_outtextxy(0, 0, "Flipping sprites"); 

	leaves.bitmap =	 &leave0;
	leaves.palette[0] = 0x34;
	leaves.posx++;
	leaves.b0 = BPP_4 | TYPE_NORMAL;
	tgi_sprite(&leaves);

	leaves.b0 = BPP_4 | TYPE_NORMAL | VFLIP;
	leaves.palette[0] = 0x9a;
	leaves.posy--;
	tgi_sprite(&leaves);

	leaves.b0 = BPP_4 | TYPE_NORMAL | HFLIP;
	leaves.palette[0] = 0x78;
	leaves.posx--;
	leaves.posy++;
	tgi_sprite(&leaves);

	tgi_updatedisplay();
	while (tgi_busy());
	wait_joystick();

	tgi_clear();
	tgi_setcolor(TUTORIAL_COLOR_WHITE);
	tgi_outtextxy(0, 0, "Reference points"); 

	tgi_sprite(&robot2);

	tgi_updatedisplay();
	while (tgi_busy());
	wait_joystick();
}

void initialize()
{
	tgi_install(&lynxtgi);
	tgi_init();
	CLI();
	
	while (tgi_busy());

	tgi_setbgcolor(COLOR_BLACK); 
	tgi_setpalette(palette);
	
	tgi_setcolor(COLOR_BLACK);
	tgi_clear();
}

void main(void) 
{	
	initialize();

	while (1)
	{
		show_screen();
	};
}