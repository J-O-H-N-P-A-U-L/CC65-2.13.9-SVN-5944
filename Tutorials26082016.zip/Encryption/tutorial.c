#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <joystick.h>
#include <stdlib.h>

extern unsigned char lynxtgi[];
extern unsigned char lynxjoy[];

char joy;

void wait_joystick()
{
	__asm__("press:		lda $FCB0");
	__asm__("					beq press");
	__asm__("release: lda $FCB0");
	__asm__("					bne release"); 
} 

void show_startscreen()
{
	tgi_clear();
	tgi_setcolor(COLOR_RED);
	tgi_outtextxy(10, 40, "Hello World!"); 
	tgi_updatedisplay();
	while (tgi_busy()) ;
}

void initialize()
{
	tgi_install(&tgi_static_stddrv);
	joy_install(&joy_static_stddrv);

	tgi_init();
	CLI();
	
	while (tgi_busy());

	tgi_setbgcolor(COLOR_BLACK);
	tgi_clear();
}

void main(void) 
{	
	initialize();
	
	while (1)
	{
		show_startscreen();
	}
}