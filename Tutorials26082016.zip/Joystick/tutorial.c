#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <joystick.h>

#define true 1
#define false 0

extern char lynxtgi[];
extern char lynxjoy[];

char posx, posy;

void show_screen()
{
	tgi_clear();
	
	tgi_setcolor(COLOR_WHITE);
	tgi_outtextxy(posx, posy, "Hello, World!");

	tgi_updatedisplay();
}

void initialize()
{
	tgi_install(&lynxtgi);
	joy_install(&lynxjoy);
	tgi_init();
	CLI();
	
	while (tgi_busy());

	tgi_setbgcolor(COLOR_BLACK); 
	tgi_setpalette(tgi_getdefpalette());
	
	tgi_setcolor(COLOR_BLACK);
	tgi_clear();
	posx = 30;
	posy = 48;
}

void main(void) 
{
	unsigned char joy;
	unsigned char waitForRelease = false;

	initialize();

	while (1)
	{
		joy = joy_read(JOY_1);
		if (!joy) waitForRelease = false;

		if (JOY_BTN_RIGHT(joy))
		{
			posx++;
		}
		if (JOY_BTN_LEFT(joy))
		{
			posx--;
		}

		if (JOY_BTN_FIRE(joy))
		{
			waitForRelease = true;
			posx = 30;
			posy = 48;
		}
		else 
		{ 
			waitForRelease = false;
		}

		if (!tgi_busy())
		{
			show_screen();
		}
	};
}