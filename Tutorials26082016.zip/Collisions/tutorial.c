#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <joystick.h>
#include <stdlib.h>

extern unsigned char lynxtgi[];
extern unsigned char lynxjoy[];
extern unsigned char robot[];
extern unsigned char robotcentered[];

unsigned char singlepixel_data[4] = { 0x03, 0x87, 0x80, 0x00 }; // 1 0000 111 1 0000 000 

char joy;

void wait_joystick()
{
	__asm__("press:		lda $FCB0");
	__asm__("					beq press");
	__asm__("release: lda $FCB0");
	__asm__("					bne release");
}

typedef struct sprite_collideable
{
	unsigned char depository;
	SCB_REHV_PAL scb;
} sprite_collideable;

sprite_collideable wall = 
{
	0x0, 
	{
		BPP_4 | TYPE_NORMAL, 
		REHV, 
		0x8,
		0,
		singlepixel_data,
		50, 20, 0x0a00, 0x1a00,
		{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
	}
};

sprite_collideable wall2 = 
{
	0x0, 
	{
		BPP_4 | TYPE_NORMAL, 
		REHV, 
		0x6,
		0,
		singlepixel_data,
		65, 20, 0x0a00, 0x1a00,
		{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
	}
};

sprite_collideable robotsprite = 
{
	0x0, 
	{
		BPP_4 | TYPE_NORMAL,
		REHV,
		0x01,
		0,
		robot,
		20, 50,
		0x0100, 0x0100,
		{ 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef }
	}
};

void show_screen()
{
	char text[20];

	tgi_clear();

	tgi_setcolor(COLOR_WHITE);
	tgi_outtextxy(0, 0, "Avoid walls enemies"); 

	tgi_sprite(&wall.scb);
	tgi_sprite(&wall2.scb);
	tgi_sprite(&robotsprite.scb);

	if (robotsprite.depository > 1)
	{
		tgi_outtextxy(0, 90, "Ouch!");
		itoa(robotsprite.depository, text, 10);
		tgi_outtextxy(50, 90, text);
	}

	tgi_setcolor(COLOR_RED);
	tgi_outtextxy(51, 25, "8");
	tgi_setcolor(COLOR_GREEN);
	tgi_outtextxy(66, 25, "6");

	tgi_updatedisplay();
	while (tgi_busy());
}

void initialize()
{
	tgi_install(&lynxtgi);
	joy_install(&lynxjoy);
	tgi_init();
	CLI();
	
	while (tgi_busy());

	tgi_setbgcolor(COLOR_BLACK); 
	//tgi_setpalette(palette);
	tgi_setcolor(COLOR_BLACK);

	// Turn on collision detection
	tgi_setcollisiondetection(1);
	tgi_clear();
}

void read_input()
{
	joy = joy_read(JOY_1);

	if (JOY_BTN_LEFT(joy))
	{
		if (robotsprite.scb.hpos > 0) robotsprite.scb.hpos--;
	}
	if (JOY_BTN_RIGHT(joy))
	{
		if (robotsprite.scb.hpos < 160) robotsprite.scb.hpos++;
	}
	if (JOY_BTN_DOWN(joy))
	{
		if (robotsprite.scb.vpos < 100) robotsprite.scb.vpos++;
	}
	if (JOY_BTN_UP(joy))
	{
		if (robotsprite.scb.vpos > 0) robotsprite.scb.vpos--;
	}
}

void main(void) 
{	
	initialize();

	while (1)
	{
		read_input();
		show_screen();
	};
}