#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <joystick.h>
#include <stdlib.h>
#include <peekpoke.h>

#include <serial.h>

extern unsigned char lynxtgi[];
extern unsigned char lynxjoy[];
extern unsigned char comlynx[];

void wait_joystick()
{
	__asm__("press:		lda $FCB0");
	__asm__("					beq press");
	__asm__("release: lda $FCB0");
	__asm__("					bne release");
}

void initialize()
{
	tgi_install(&lynxtgi);
	joy_install(&lynxjoy);

	tgi_init();
	CLI();

	while (tgi_busy());

	tgi_setbgcolor(COLOR_BLACK);
	tgi_clear();
}

void main(void) 
{	
	unsigned char data, count = 0;
	char joy;
	char text[20];

	initialize();

	joy = PEEK(0xBFD3);
	itoa(joy, text, 10);
	tgi_clear();
	tgi_outtextxy(10, 10, text);
	while (tgi_busy());
	wait_joystick();

	MIKEY.timer4.control = 0x18; // %00011000
	MIKEY.timer4.reload = 12; //0x01;
	
	MIKEY.serctl = 0x04|0x01;
	// Dummy read
	data = MIKEY.serdat;
	
	MIKEY.serctl = 0x10|0x04|0x01|0x08; // 0x40|
	//MIKEY.SERCTL = TxParEnable|TxOpenColl|ParEven|ResetErr; //	RxIntEnable|

	// Clear receive buffer
	while ((MIKEY.serctl & 0x40) == 0x40)
	{
		data = MIKEY.serdat;
	}

	MIKEY.serctl = 0x40 | 0x10 | 0x04 | 0x01 | 0x08;
	 
	while (1)
	{
		tgi_clear();
		itoa(MIKEY.timer4.count, text, 10);
		tgi_outtextxy(10, 40, text);
		joy = joy_read(JOY_1);
		itoa(joy, text, 10);
		tgi_outtextxy(10, 50, text);
		itoa(MIKEY.serctl, text, 16);
		tgi_outtextxy(10, 60, text);
		//itoa(receivecount, text, 10);
		//tgi_outtextxy(10, 70, text);
		tgi_outtextxy(10, 10, "Upload your game!");
		tgi_updatedisplay();
		while (tgi_busy());
	}

	//while (1)
	//{
	//	tgi_clear();
	//	itoa(MIKEY.timer4.count, text, 10);
	//	tgi_outtextxy(0, 40, text);
	//	
	//	if ((MIKEY.serctl & 0x40) == 0x40)
	//	{
	//		count++;
	//		data = MIKEY.serdat;
	//		itoa(data, text, 10);
	//		tgi_outtextxy(0, 0, "data");
	//		tgi_outtextxy(0, 10, text);

	//		itoa(count, text, 10);
	//		tgi_outtextxy(0, 20, text);
	//	}
	//	tgi_updatedisplay();
	//}
	
	wait_joystick();

	tgi_clear();
	tgi_outtextxy(10, 10, "Oops!!!");
	tgi_updatedisplay();
	while (1) 
		;
}