#include <6502.h>
#include <lynx.h>
#include <tgi.h>
#include <joystick.h>
#include <stdlib.h>

#include <serial.h>

extern unsigned char lynxtgi[];
extern unsigned char lynxjoy[];
extern unsigned char comlynx[];

char joy;
char text[20]; 

void wait_joystick()
{
	__asm__("press:		lda $FCB0");
	__asm__("					beq press");
	__asm__("release: lda $FCB0");
	__asm__("					bne release");
}

void initialize()
{
	tgi_install(&lynxtgi);
	joy_install(&lynxjoy);

	tgi_init();
	CLI();
	
	while (tgi_busy());

	tgi_setbgcolor(COLOR_BLACK);
	tgi_clear();
}

void main(void) 
{	
	char noexp;

	initialize();
	
	MIKEY.iodir = 0X00;
	while (1)
	{
		noexp = MIKEY.iodat;
		tgi_clear();
		itoa(noexp, text, 16);
	
		// Try connecting your ComLynx cable to see the effect
		tgi_outtextxy(5, 5, "Plug/unplug ComLynx");
		tgi_outtextxy(5, 20, text);  
		tgi_updatedisplay();
		while (tgi_busy());
	}
}